// import React, { useState } from "react";
// import {
//   Card,
//   CardHeader,
//   Button,
//   Caption1,
//   Link,
// } from "@fluentui/react-components";
// import { MoreHorizontal20Regular, ArrowCircleLeftRegular } from "@fluentui/react-icons";
// import { Rating } from "@fluentui/react-components";
// import Demo from "./Main/ProgressBar";
// import Bar from "./Main/ProgressBar";

// interface ParentProps {
//   aiWrittenPercentage: any;
//   updatedParagraphs: Array<{
//     originalText: string;
//     updatedText: string;
//     pointsThatsUpdated: string;
//     updatedWords: string[];
//     aiWrittenPercentage: any;
//   }>;
//   setisresponse: (data: boolean | null) => void;
// }

// const InsertUpdates: React.FC<ParentProps> = ({
//   updatedParagraphs,
//   aiWrittenPercentage,
//   setisresponse,
// }) => {
//   const [expandedIndexes, setExpandedIndexes] = useState<number[]>([]);
//   const [expandedPointsIndexes, setExpandedPointsIndexes] = useState<number[]>([]);

//   // Highlight updated words
//   const highlightUpdatedWords = (text: string, updatedWords: string[] = []) => {
//     if (!Array.isArray(updatedWords) || updatedWords.length === 0) {
//       return text;
//     }
//     let highlightedText = text;
//     updatedWords.forEach((word) => {
//       const regex = new RegExp(`\\b${word}\\b`, "gi");
//       highlightedText = highlightedText.replace(
//         regex,
//         `<span style="background-color: yellow; color: red; font-weight: bold;">${word}</span>`
//       );
//     });
//     return highlightedText;
//   };

//   // Restrict text to a preview of ~2 sentences or 25 words
//   const getPreviewText = (text: string, wordLimit = 25) => {
//     const words = text.split(" ");
//     return words.length > wordLimit
//       ? words.slice(0, wordLimit).join(" ") + "..."
//       : text;
//   };

//   const toggleExpand = (index: number) => {
//     setExpandedIndexes((prev) =>
//       prev.includes(index) ? prev.filter((i) => i !== index) : [...prev, index]
//     );
//   };

//   const togglePointsExpand = (index: number) => {
//     setExpandedPointsIndexes((prev) =>
//       prev.includes(index) ? prev.filter((i) => i !== index) : [...prev, index]
//     );
//   };

//   return (
//     <div style={{ padding: "5px", backgroundColor: "#f9f9f9" }}>
//       <div onClick={() => setisresponse(null)} style={{ border: "none", padding:'8px' }}>
//         <ArrowCircleLeftRegular fontSize={"25px"} />
//       </div>
//       <div style={{width:'100%', display:'flex', justifyContent:'center', alignItems:'center'}}>

//       <Bar percentage={aiWrittenPercentage}/>
//       </div>
//       {updatedParagraphs.length === 0 ? (
//         <p>No updates available</p>
//       ) : (
//         updatedParagraphs.map((paragraph, index) => {
//           const highlightedUpdatedText = highlightUpdatedWords(
//             paragraph.updatedText,
//             paragraph.updatedWords || []
//           );
//           const isExpanded = expandedIndexes.includes(index);
//           const arePointsExpanded = expandedPointsIndexes.includes(index);

//           return (
//             <Card
//               key={index}
//               style={{
//                 margin: "20px 0",
//                 padding: "20px",
//                 borderRadius: "12px",
//                 boxShadow: "0 4px 10px rgba(0, 0, 0, 0.1)",
//                 backgroundColor: "#fefefe",
//                 transition: "transform 0.2s, box-shadow 0.2s",
//               }}
//             >
//               <CardHeader
//                 description={
//                   <Caption1 style={{ color: "#666" }}>Update Details</Caption1>
//                 }
//                 action={
//                   <Button
//                     appearance="transparent"
//                     icon={<MoreHorizontal20Regular />}
//                     aria-label="More options"
//                   />
//                 }
//               />
//               <div>
//                 <strong>Original Text:</strong>{" "}
//                 {getPreviewText(paragraph.originalText, 10)}
//               </div>
//               <div
//                 style={{
//                   margin: "10px 0",
//                   fontSize: "16px",
//                   lineHeight: "1.5",
//                 }}
//               >
//                 <strong>Updated Text:</strong>{" "}
//                 {isExpanded ? (
//                   <span
//                     dangerouslySetInnerHTML={{
//                       __html: highlightedUpdatedText,
//                     }}
//                   />
//                 ) : (
//                   <span
//                     dangerouslySetInnerHTML={{
//                       __html: getPreviewText(highlightedUpdatedText, 10),
//                     }}
//                   />
//                 )}
//                 <Link
//                   onClick={() => toggleExpand(index)}
//                   style={{
//                     marginLeft: "5px",
//                     fontSize: "14px",
//                     color: "#0078d4",
//                     cursor: "pointer",
//                   }}
//                 >
//                   {isExpanded ? "Read Less" : "Read More"}
//                 </Link>
//               </div>
//               <div style={{ color: "green" }}>
//                 <strong>Points Updated:</strong>{" "}
//                 {arePointsExpanded ? (
//                   <span>{paragraph.pointsThatsUpdated || "N/A"}</span>
//                 ) : (
//                   <span>{getPreviewText(paragraph.pointsThatsUpdated || "N/A", 10)}</span>
//                 )}
//                 <Link
//                   onClick={() => togglePointsExpand(index)}
//                   style={{
//                     marginLeft: "5px",
//                     fontSize: "14px",
//                     color: "#0078d4",
//                     cursor: "pointer",
//                   }}
//                 >
//                   {arePointsExpanded ? "Read Less" : "Read More"}
//                 </Link>
//               </div>
//               <div
//                 style={{
//                   display: "flex",
//                   justifyContent: "space-between",
//                   alignItems: "center",
//                   marginTop: "15px",
//                   flexDirection: "column",
//                 }}
//               >
//                 <Button
//                   appearance="primary"
//                   style={{
//                     backgroundColor: "#0078d4",
//                     color: "#fff",
//                     width: "90%",
//                   }}
//                 >
//                   Replace with Updated Text
//                 </Button>
//                 <Rating max={5} color="marigold" defaultValue={5} />
//               </div>
//             </Card>
//           );
//         })
//       )}
//     </div>
//   );
// };

// export default InsertUpdates;
import React, { useState } from "react";
import {
  Card,
  Button,
  Link,
  Body1,
  Accordion,
  AccordionHeader,
  AccordionItem,
  AccordionPanel,
  Text,
  Rating,
  Label,
} from "@fluentui/react-components";
import { ArrowCircleLeftRegular, ChevronDownRegular, ChevronUpRegular } from "@fluentui/react-icons";
import Bar from "./Main/ProgressBar";

interface ParentProps {
  aiWrittenPercentage: string; // String format percentage from the API
  updatedParagraphs: Array<{
    highlightedText: string;
    originalText: string;
    updatedText: string;
    pointsThatsUpdated: string;
  }>;
  setisresponse: (data: boolean | null) => void;
}

const InsertUpdates: React.FC<ParentProps> = ({
  updatedParagraphs,
  aiWrittenPercentage = "0%", // Default to 0% if not provided
  setisresponse,
}) => {
  const [expandedIndexes, setExpandedIndexes] = useState<number[]>([]);

  // Convert percentage string like "40.00%" to a number (40)
  const aiWrittenPercentageValue = parseFloat(aiWrittenPercentage.replace('%', ''));

  // Restrict text to a preview of ~25 words
  const getPreviewText = (text: string, wordLimit = 25) => {
    const words = text.split(" ");
    return words.length > wordLimit
      ? words.slice(0, wordLimit).join(" ") + "..."
      : text;
  };

  const toggleExpand = (index: number) => {
    setExpandedIndexes((prev) =>
      prev.includes(index) ? prev.filter((i) => i !== index) : [...prev, index]
    );
  };

  return (
    <div
      style={{
        padding: "32px",
        backgroundColor: "#f9f9f9",
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: "32px",
      }}
    >
      {/* Back Button */}
      <Button
        onClick={() => setisresponse(null)}
        appearance="subtle"
        icon={<ArrowCircleLeftRegular />}
        style={{
          alignSelf: "flex-start",
          padding: "8px 16px",
          fontSize: "16px",
        }}
      >
        Back
      </Button>

      {/* Progress Bar */}
      <div style={{ width: "100%", maxWidth: "800px", marginBottom: "32px" }}>
        <Bar percent={aiWrittenPercentageValue} />
      </div>

      {/* No Updates Message */}
      {updatedParagraphs.length === 0 ? (
        <Body1 style={{ fontSize: "18px", color: "#666" }}>No updates available</Body1>
      ) : (
        <Accordion
          // defaultActiveItems={expandedIndexes}
          style={{ width: "100%", maxWidth: "800px" }}
        >
          {updatedParagraphs.map((paragraph, index) => {
            if (!paragraph || !paragraph.updatedText || !paragraph.highlightedText) {
              return null; // Skip invalid paragraph data
            }

            return (
              <AccordionItem key={index} value={String(index)}>
                <AccordionHeader
                  style={{
                    backgroundColor: "#e3e3e3",
                    borderRadius: "8px",
                    padding: "12px 16px",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    boxShadow: "0px 2px 5px rgba(0, 0, 0, 0.1)",
                    cursor: "pointer",
                    fontWeight: "bold",
                  }}
                >
                  <Text style={{ fontSize: "18px" }}>Update {index + 1}</Text>
                  <div>
                    {expandedIndexes.includes(index) ? (
                      <ChevronUpRegular />
                    ) : (
                      <ChevronDownRegular />
                    )}
                  </div>
                </AccordionHeader>
                <AccordionPanel>
                  <Card
                    style={{
                      margin: "16px 0",
                      padding: "16px",
                      borderRadius: "12px",
                      boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)",
                      backgroundColor: "#ffffff",
                      transition: "transform 0.3s ease, box-shadow 0.3s ease",
                    }}
                  >
                    {/* Original Text */}
                    <div style={{ marginBottom: "16px" }}>
                      <Label style={{ fontWeight: "bold" }}>Original Text:</Label>
                      <Body1 style={{ fontSize: "16px", color: "#333" }}>
                        {getPreviewText(paragraph.originalText)}
                      </Body1>
                    </div>

                    {/* Updated Text */}
                    <div style={{ marginBottom: "16px" }}>
                      <Label style={{ fontWeight: "bold" }}>Updated Text:</Label>
                      <Body1 style={{ fontSize: "16px", color: "#333" }}>
                        <span
                          dangerouslySetInnerHTML={{
                            __html: paragraph.highlightedText, // Directly use the highlighted HTML
                          }}
                        />
                        <Link
                          onClick={() => toggleExpand(index)}
                          style={{
                            marginLeft: "8px",
                            cursor: "pointer",
                            fontWeight: "bold",
                            color: "#0078d4",
                          }}
                        >
                          {expandedIndexes.includes(index) ? "Read Less" : "Read More"}
                        </Link>
                      </Body1>
                    </div>

                    {/* Points Updated */}
                    <div style={{ marginBottom: "16px" }}>
                      <Label style={{ fontWeight: "bold" }}>Points Updated:</Label>
                      <Body1 style={{ fontSize: "16px", color: "#666" }}>
                        {paragraph.pointsThatsUpdated}
                      </Body1>
                    </div>

                    {/* Action Buttons */}
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        gap: "16px",
                      }}
                    >
                      <Button
                        appearance="primary"
                        style={{
                          padding: "8px 20px",
                          fontSize: "16px",
                          fontWeight: "bold",
                          backgroundColor: "#0078d4",
                          color: "#fff",
                        }}
                      >
                        Replace with Updated Text
                      </Button>
                      <Rating max={5} value={5} style={{ display: "flex", alignItems: "center" }} />
                    </div>
                  </Card>
                </AccordionPanel>
              </AccordionItem>
            );
          })}
        </Accordion>
      )}
    </div>
  );
};

export default InsertUpdates;
