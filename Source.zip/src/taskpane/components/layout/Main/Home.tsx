// import React, { useEffect, useState } from 'react';
// import {
//   Box,
//   Tab,
//   Tabs,
//   Typography,
//   Button,
//   TextField,
//   List,
//   ListItem,
//   ListItemButton,
//   ListItemIcon,
//   ListItemText,
//   Divider,
// } from '@mui/material';
// import { FaFile } from "react-icons/fa";
// import { FaFileImage } from "react-icons/fa6";

// const AttachmentSorter = () => {
//   const [value, setValue] = useState(0);
//   const [attachments, setAttachments] = useState([]);

//   // Function to determine the icon based on attachment type
//   const getIcon = (type: string) => {
//     if (type === 'image/png' || type === 'image/jpeg') {
//       return <FaFileImage />;
//     } else {
//       return <FaFile />;
//     }
//   };

//   useEffect(() => {
//     const attachments = Office.context.mailbox.item.attachments;
//     console.log(attachments);
//     setAttachments(attachments || []);
//   }, []);

//   const handleTabChange = (__event: React.SyntheticEvent, newValue: number) => {
//     setValue(newValue);
//   };


//   const SendEmailWithAttachments = (token) => {
//       var item = Office.context.mailbox.item;
//       if (item.itemType === Office.MailboxEnums.ItemType.Message) {
//       } else {
//         console.log("This is not an email message.");
//       }
//       var emailSettings = {
//         url: "https://graph.microsoft.com/v1.0/me/sendMail",
//         method: "POST",
//         timeout: 0,
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: "Bearer " + token,
//         },
//         data: JSON.stringify({
//           message: {
//             subject: item.subject,
//             body: {
//               contentType: "text",
//               // content: "Sender: " + sender + "\nSuspicious Address: " + fromEmail.emailAddress,
//             },
//             toRecipients: [
//               {
//                 emailAddress: {
//                   address: "shahzad890.it@outlook.com",
//                 },
//               },
//             ],
//             attachments: [
//               {
//                 "@odata.type": "#microsoft.graph.fileAttachment",
//                 name: "email.msg",
//                 contentType: "application/octet-stream",
//                 contentBytes: base64,
//               },
//             ],
//           },
//           saveToSentItems: "false",
//         }),
//       };
    
//       return fetch(emailSettings.url, {
//         method: emailSettings.method,
//         headers: emailSettings.headers,
//         body: emailSettings.data,
//       }).then((response) => {
//         if (!response.ok) {
//           throw new Error("Error sending email: " + response.status);
//         }
//         return response;
//       })
//         .then(() => {
//           console.log('mail send successfullt');
          
//         })
//         .catch((error) => {
//           console.error("Error:", error);
//         });
    
//   };


  
//   return (
//     <Box sx={{ width: '100%' }}>
//       <Tabs
//         TabIndicatorProps={{
//           style: {
//             backgroundColor: 'black', // Indicator line color
//           },
//         }}
//         value={value}
//         onChange={handleTabChange}
//         aria-label="Attachment and Text Management Tabs"
//         style={{ background: '#0095ff' }}
//       >
//         <Tab label="Send Mail" style={{ width: '33%', fontWeight: 'bold', color: 'white' }} />
//         <Tab label="Upload" style={{ width: '33%', fontWeight: 'bold', color: 'white' }} />
//         <Tab label="PDF Converter" style={{ width: '33%', fontWeight: 'bold', color: 'white' }} />
//       </Tabs>
//       <Box sx={{ padding: 2 }}>
//         {value === 0 && (
//           <Box>
//             <Typography variant="h6">Attachments</Typography>
//             <Box>
//               <List>
//                 {attachments.map((attachment) => (
//                   <React.Fragment key={attachment.id}>
//                     <ListItem
//                       disablePadding
//                       style={{
//                         boxShadow: '0px 0px 0px 1px rgb(226, 225, 225)',
//                         marginBottom: '4px',
//                       }}
//                     >
//                       <ListItemButton>
//                         <ListItemIcon>{getIcon(attachment.contentType)}</ListItemIcon>
//                         <ListItemText primary={attachment.name} />
//                       </ListItemButton>
//                     </ListItem>
//                     <Divider />
//                   </React.Fragment>
//                 ))}
//               </List>
//             </Box>
//             <TextField
//               label="type mail body"
//               variant="outlined"
//               fullWidth
//               multiline
//               rows={4}
//               placeholder="Select text from the email"
//               margin="normal"
//             />
//             <TextField
//               label="Email Address"
//               variant="outlined"
//               fullWidth
//               margin="normal"
//               placeholder="Enter your email"
//             />
//             <Button variant="outlined" fullWidth>
//               Send Attachment
//             </Button>
//           </Box>
//         )}


//         {value === 1 && (
//           <Box>
//             <Typography variant="h6">Upload To OneDrive</Typography>
//             <TextField
//               label="Text to Convert"
//               variant="outlined"
//               fullWidth
//               multiline
//               rows={4}
//               placeholder="Select text from the email"
//               margin="normal"
//             />
//             <Button variant="outlined">Upload</Button>
//           </Box>
//         )}



//         {value === 2 && (
//           <Box>
//             <Typography variant="h6">Convert Text to PDF</Typography>
//             <TextField
//               label="Text to Convert"
//               variant="outlined"
//               fullWidth
//               multiline
//               rows={4}
//               placeholder="Select text from the email"
//               margin="normal"
//             />
//             <Button variant="outlined">Convert to PDF</Button>
//           </Box>
//         )}
//       </Box>
//     </Box>
//   );
// };

// export default AttachmentSorter;

import React, { useEffect, useState } from "react";
import {
  Box,
  Tab,
  Tabs,
  Typography,
  Button,
  TextField,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Divider,
  Snackbar,
  Alert,
  CircularProgress,
} from "@mui/material";
import {
  FaFile,
  FaFileImage,
  FaFilePdf,
  FaFileWord,
  FaFileExcel,
  FaFilePowerpoint,
  FaFileAlt,
  FaFileArchive,
  FaFileAudio,
  FaFileVideo,
  FaFileCode,
  FaDatabase,
  FaFileCsv,
} from "react-icons/fa";
import UploadAttachmentsToOneDrive from "./UploadAttachmentsToOneDrive";
import LoaderApp from "../../Loader/Loader";
import SendMailTab from "./SendMail";
import { useNavigate } from 'react-router-dom';
import PDFGenrator from "./PDFGenrator";



const AttachmentSorter: React.FC = () => {
  const [value, setValue] = useState(0);
  const [isSending, setIsSending] = useState(false);
  const [attachments, setAttachments] = useState<any[]>([]);
  const [emailBody, setEmailBody] = useState("");
  const [recipientEmail, setRecipientEmail] = useState("");
  const [ValidToken, setValidToken] = useState("");
  const [Loading, setLoading] = useState(false);
  const [SelectedemailBody, setSelectedemailBody] = useState("");

  const [toast, setToast] = useState({
    open: false,
    severity: "info", // info, success, warning, error
    message: "",
  });
  const navigate = useNavigate();

  useEffect(() => {
    const checkTokenValidity = () => {
      const token = localStorage.getItem('Token');
      if(!token){
        navigate('/')
      }
      setValidToken(token)
    };

    // Check once on load
    checkTokenValidity();

    // Check every minute
    const interval = setInterval(checkTokenValidity, 60000);

    return () => clearInterval(interval); // Cleanup on component unmount
  }, [navigate]);

  useEffect(() => {
    setLoading(true)
    getSelectedEmailBody()
    const attachments = Office.context.mailbox.item.attachments || [];
    setAttachments(attachments);
    setLoading(false)
  }, []);

  // Function to determine the icon based on attachment type
 
  
  function getSelectedEmailBody() {
    // Ensure the item is a message
    const item = Office.context.mailbox.item;
  
    if (item) {
      item.body.getAsync(Office.CoercionType.Text, (result) => {
        if (result.status === Office.AsyncResultStatus.Succeeded) {
          console.log("Email body retrieved successfully:");
          console.log(result.value); // HTML content of the email body
          setSelectedemailBody(result.value)

        } else {
          console.error("Failed to get email body:", result.error.message);
        }
      });
    } else {
      console.error("No email item is selected.");
    }
  }
 
  const fetchAttachmentContent = async (attachmentId: string): Promise<string> => {
    return new Promise((resolve, reject) => {
      Office.context.mailbox.item.getAttachmentContentAsync(attachmentId, (result) => {
        if (result.status === Office.AsyncResultStatus.Succeeded) {
          resolve(result.value.content);
        } else {
          console.error("Failed to fetch attachment content:", result.error.message);
          reject(result.error.message);
        }
      });
    });
  };

  const prepareAttachments = async () => {
    const preparedAttachments = await Promise.all(
      attachments.map(async (attachment) => {
        const contentBytes = await fetchAttachmentContent(attachment.id);
        return {
          "@odata.type": "#microsoft.graph.fileAttachment",
          name: attachment.name,
          contentType: attachment.contentType,
          contentBytes,
        };
      })
    );
    return preparedAttachments;
  };

  const sendEmailWithAttachments = async (token: string) => {
    try {
      const attachmentData = await prepareAttachments();

      const emailData = {
        message: {
          subject: "Email from Attachment Sorter",
          body: {
            contentType: "Text",
            content: emailBody,
          },
          toRecipients: [
            {
              emailAddress: {
                address: recipientEmail,
              },
            },
          ],
          attachments: attachmentData,
        },
        saveToSentItems: "true",
      };

      const response = await fetch("https://graph.microsoft.com/v1.0/me/sendMail", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(emailData),
      });

      if (response.ok) {
        setIsSending(false)
    setLoading(false)

        setToast({
          open: true,
          severity: "success",
          message: "Email sent successfully!",
        });
      } else {
        const errorData = await response.json();
        console.error("Error sending email:", errorData);
    setLoading(false)

        setIsSending(false)
        setToast({
          open: true,
          severity: "error",
          message: errorData.error.message || "Unknown error occurred.",
        });
      }
    } catch (error) {
      console.error("Error:", error);
    setLoading(false)

      setToast({
        open: true,
        severity: "error",
        message: `Failed to send email: ${error}`,
      });
    }
  };

  const handleSendAttachment = async () => {
    setLoading(true)
    setIsSending(true)
    if (!recipientEmail) {
    setLoading(false)

      setIsSending(false)
      setToast({
        open: true,
        severity: "warning",
        message: "Please enter a valid recipient email address.",
      });
      return;
    }
   let storeToken=localStorage.getItem('Token')
    sendEmailWithAttachments(ValidToken);
  };

  const handleTabChange = (_event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
  };

  const handleToastClose = (_event?: React.SyntheticEvent | Event, reason?: string) => {
    if (reason === "clickaway") return;
    setToast({ ...toast, open: false });
  };

  return (
    <Box sx={{ width: "100%" }}>
      {Loading && (<LoaderApp/>)}
      <Tabs
        TabIndicatorProps={{
          style: {
            backgroundColor: "black",
          },
        }}
        value={value}
        onChange={handleTabChange}
        aria-label="Attachment and Text Management Tabs"
        style={{ background: "#0095ff" }}
      >
        <Tab label="Send Mail" style={{ width: "33%", fontWeight: "bold", color: "white" }} />
        <Tab label="Upload" style={{ width: "33%", fontWeight: "bold", color: "white" }} />
        <Tab label="Send PDF " style={{ width: "33%", fontWeight: "bold", color: "white" }} />
        
      </Tabs>
      <Box sx={{ padding: 2 }}>
        {value === 0 && (
          <Box>
            {/* <Typography variant="h6">Attachments</Typography>
            <Box sx={{maxHeight:'300px', overflow:'auto'}}>
              <List>
                {attachments.map((attachment) => (
                  <React.Fragment key={attachment.id}>
                    <ListItem
                      disablePadding
                      style={{
                        boxShadow: "0px 0px 0px 1px rgb(226, 225, 225)",
                        marginBottom: "4px",
                      }}
                    >
                      <ListItemButton>
                        <ListItemIcon>{getIcon(attachment.contentType)}</ListItemIcon>
                        <ListItemText primary={attachment.name} />
                      </ListItemButton>
                    </ListItem>
                    <Divider />
                  </React.Fragment>
                ))}
              </List>
            </Box>
            <TextField
              label="Email Body"
              variant="outlined"
              fullWidth
              multiline
              rows={4}
              placeholder="Enter your email body"
              margin="normal"
              value={emailBody}
              onChange={(e) => setEmailBody(e.target.value)}
            />
            <TextField
              label="Recipient Email Address"
              variant="outlined"
              fullWidth
              margin="normal"
              placeholder="Enter recipient email"
              value={recipientEmail}
              onChange={(e) => setRecipientEmail(e.target.value)}
            />
            <Button
    variant="outlined"
    fullWidth
    onClick={handleSendAttachment}
    disabled={isSending}
  >
    {isSending ? <CircularProgress size={24} /> : 'Send Attachment'}
  </Button> */}
   <SendMailTab />
          </Box>
        )}

        {value === 1 && (
          <UploadAttachmentsToOneDrive  />
        )}

        {value === 2 && (
        <PDFGenrator/>
        )}
      </Box>
      {/* Snackbar for Toast Messages */}
      <Snackbar
        open={toast.open}
        autoHideDuration={6000}
        onClose={handleToastClose}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <Alert onClose={handleToastClose} severity={toast.severity as any} sx={{ width: "100%" }}>
          {toast.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default AttachmentSorter;
