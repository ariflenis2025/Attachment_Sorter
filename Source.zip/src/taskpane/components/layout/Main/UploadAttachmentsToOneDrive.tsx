// import React, { useEffect, useState } from "react";
// import {
//   Box,
//   Typography,
//   Button,
//   List,
//   ListItem,
//   ListItemIcon,
//   ListItemText,
//   CircularProgress,
//   Snackbar,
//   Alert,
//   ListItemButton,
//   Checkbox,
//   Divider,
// } from "@mui/material";
// import {
//   FaFile,
//   FaFileImage,
//   FaFilePdf,
//   FaFileWord,
//   FaFileExcel,
//   FaFilePowerpoint,
//   FaCloudUploadAlt,
//   FaDatabase,
//   FaFileAlt,
//   FaFileArchive,
//   FaFileAudio,
//   FaFileCode,
//   FaFileCsv,
//   FaFileVideo,
// } from "react-icons/fa";
// import axios from "axios";
// import LoaderApp from "../../Loader/Loader";

// interface Attachment {
//   id: string;
//   name: string;
//   contentType: string;
//   contentBytes?: string; // Added for content storage
// }

// const UploadAttachmentsToOneDrive = ({ accessToken }: { accessToken: string }) => {
//   const [attachments, setAttachments] = useState<Attachment[]>([]);
//   const [selectedAttachments, setSelectedAttachments] = useState<string[]>([]); // IDs of selected attachments
//   const [isUploading, setIsUploading] = useState(false);
//   const [uploadSuccess, setUploadSuccess] = useState(false);
//   const [errorMessage, setErrorMessage] = useState("");
//   const [loading, setLoading] = useState(false);

//   useEffect(() => {
//     setLoading(true);
//     const fetchAttachments = async () => {
//       const emailAttachments = Office.context.mailbox.item.attachments || [];
//       const preparedAttachments = await prepareAttachments(emailAttachments);
//       setAttachments(preparedAttachments);
//       setLoading(false);
//     };

//     fetchAttachments();
//   }, []);

//   const fetchAttachmentContent = async (attachmentId: string): Promise<string> => {
//     return new Promise((resolve, reject) => {
//       Office.context.mailbox.item.getAttachmentContentAsync(attachmentId, (result) => {
//         if (result.status === Office.AsyncResultStatus.Succeeded) {
//           resolve(result.value.content);
//         } else {
//           console.error("Failed to fetch attachment content:", result.error.message);
//           reject(result.error.message);
//         }
//       });
//     });
//   };

//   const prepareAttachments = async (attachments: Attachment[]) => {
//     return Promise.all(
//       attachments.map(async (attachment) => {
//         try {
//           const contentBytes = await fetchAttachmentContent(attachment.id);
//           return { ...attachment, contentBytes };
//         } catch (error) {
//           console.error("Error preparing attachment:", attachment.name, error);
//           return { ...attachment, contentBytes: null }; // Handle missing content gracefully
//         }
//       })
//     );
//   };

//   const toggleAttachmentSelection = (id: string) => {
//     setSelectedAttachments((prev) =>
//       prev.includes(id) ? prev.filter((attachmentId) => attachmentId !== id) : [...prev, id]
//     );
//   };

//   const uploadToPath = async (path: string) => {
//     if (selectedAttachments.length === 0) {
//       setErrorMessage("No attachments selected for upload.");
//       return;
//     }

//     setIsUploading(true);
//     setErrorMessage("");

//     try {
//       for (const attachment of attachments.filter((a) => selectedAttachments.includes(a.id))) {
//         if (!attachment.contentBytes) continue; // Skip attachments without content

//         const uploadUrl = `https://graph.microsoft.com/v1.0/me/drive/root:/${path}/${attachment.name}:/content`;
//         const fileContent = Uint8Array.from(atob(attachment.contentBytes || ""), (c) => c.charCodeAt(0));

//         await axios.put(uploadUrl, fileContent, {
//           headers: {
//             Authorization: `Bearer ${accessToken}`,
//             "Content-Type": attachment.contentType,
//           },
//         });
//         console.log(`${attachment.name} uploaded successfully to ${path}`);
//       }

//       setUploadSuccess(true);
//       setSelectedAttachments([]); // Clear selected attachments after upload
//     } catch (error) {
//       setErrorMessage("Error uploading to OneDrive. Please try again.");
//       console.error("Upload error:", error);
//     } finally {
//       setIsUploading(false);
//     }
//   };

//   const getIcon = (type: string) => {
//      switch (type) {
//        // Image Files
//        case "image/png":
//        case "image/jpeg":
//        case "image/jpg":
//        case "image/gif":
//        case "image/webp":
//        case "image/svg+xml":
//        case "image/bmp":
//          return <FaFileImage color="blue" fontSize={'xx-large'} />;
   
//        // PDF Files
//        case "application/pdf":
//          return <FaFilePdf color="red" fontSize={'xx-large'}/>;
   
//        // Word Documents
//        case "application/msword":
//        case "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
//          return <FaFileWord color="blue" fontSize={'xx-large'} />;
   
//        // Excel Files
//        case "application/vnd.ms-excel":
//        case "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
//        case "text/csv":
//          return <FaFileExcel color="green" fontSize={'xx-large'}/>;
   
//        // CSV Files
//        case "text/csv":
//          return <FaFileCsv color="teal"  fontSize={'xx-large'}/>;
   
//        // PowerPoint Files
//        case "application/vnd.ms-powerpoint":
//        case "application/vnd.openxmlformats-officedocument.presentationml.presentation":
//          return <FaFilePowerpoint color="orange" fontSize={'xx-large'} />;
   
//        // Archive Files
//        case "application/zip":
//        case "application/x-7z-compressed":
//        case "application/x-rar-compressed":
//        case "application/x-tar":
//        case "application/gzip":
//          return <FaFileArchive color="brown" fontSize={'xx-large'}/>;
   
//        // Text Files
//        case "text/plain":
//          return <FaFileAlt color="gray" fontSize={'xx-large'}/>;
   
//        // Audio Files
//        case "audio/mpeg":
//        case "audio/wav":
//        case "audio/ogg":
//        case "audio/aac":
//        case "audio/x-midi":
//          return <FaFileAudio color="purple" fontSize={'xx-large'}/>;
   
//        // Video Files
//        case "video/mp4":
//        case "video/x-msvideo":
//        case "video/mpeg":
//        case "video/ogg":
//        case "video/webm":
//        case "video/x-matroska":
//          return <FaFileVideo color="red"fontSize={'xx-large'} />;
   
//        // Code Files
//        case "text/html":
//        case "application/javascript":
//        case "application/json":
//        case "text/css":
//        case "application/xml":
//          return <FaFileCode color="green"fontSize={'xx-large'} />;
   
//        // Database Files
//        case "application/vnd.ms-access":
//        case "application/x-sqlite3":
//        case "application/x-msdownload":
//          return <FaDatabase color="brown"fontSize={'xx-large'} />;
   
//        // Default (Unknown or Unhandled Types)
//        default:
//          return <FaFile color="black" fontSize={'xx-large'}/>;
//      }
//    };

//   return (
//     <Box sx={{ maxWidth: 600, margin: "auto", backgroundColor: "#fff" }}>
//       {loading && <LoaderApp/>}
//       <Typography variant="h5" sx={{ marginBottom: 2, textAlign: "center", fontWeight: "bold" }}>
//         <FaCloudUploadAlt style={{ marginRight: 8, verticalAlign: "middle" }} />
//         Upload Attachments to OneDrive
//       </Typography>

//       {/* List attachments with checkboxes */}
//       <Box sx={{ maxHeight: 300, overflow: "auto" }}>
//         <List>
//           {attachments.map((attachment) => (
//             <React.Fragment key={attachment.id}>
//               <ListItem disablePadding>
//                 <Checkbox
//                   checked={selectedAttachments.includes(attachment.id)}
//                   onChange={() => toggleAttachmentSelection(attachment.id)}
//                 />
//                 <ListItemButton>
//                   <ListItemIcon>{getIcon(attachment.contentType)}</ListItemIcon>
//                   <ListItemText primary={attachment.name} />
//                 </ListItemButton>
//               </ListItem>
//               <Divider />
//             </React.Fragment>
//           ))}
//         </List>
//       </Box>

//       {/* Buttons for three paths */}
//       <Box sx={{ marginTop: '8px' }}>
//         <Typography variant="h6" sx={{fontSize:'15px'}}>Upload to Path 1</Typography>
//         <Button
//           variant="contained"
//           color="primary"
//           fullWidth
//           disabled={isUploading}
//           onClick={() => uploadToPath("Attachments")}
//           startIcon={isUploading ? <CircularProgress size={20} /> : <FaCloudUploadAlt />}
//         >
//           {isUploading ? "Uploading..." : "Upload"}
//         </Button>
//       </Box>

//       <Box sx={{ marginTop: '8px' }}>
//         <Typography variant="h6" sx={{fontSize:'15px'}}>Upload to Path 2</Typography>
//         <Button
//           variant="contained"
//           color="secondary"
//           fullWidth
//           disabled={isUploading}
//           onClick={() => uploadToPath("Path2")}
//           startIcon={isUploading ? <CircularProgress size={20} /> : <FaCloudUploadAlt />}
//         >
//           {isUploading ? "Uploading..." : "Upload"}
//         </Button>
//       </Box>

//       <Box sx={{ marginTop: '8px'}}>
//         <Typography variant="h6" sx={{fontSize:'15px'}}>Upload to Path 3</Typography>
//         <Button
//           variant="contained"
//           color="success"
//           fullWidth
//           disabled={isUploading}
//           onClick={() => uploadToPath("Path3")}
//           startIcon={isUploading ? <CircularProgress size={20} /> : <FaCloudUploadAlt />}
//         >
//           {isUploading ? "Uploading..." : "Upload"}
//         </Button>
//       </Box>

//       {/* Error message */}
//       {errorMessage && (
//         <Alert severity="error" sx={{ marginTop: 2 }} onClose={() => setErrorMessage("")}>
//           {errorMessage}
//         </Alert>
//       )}

//       {/* Success message */}
//       <Snackbar
//         open={uploadSuccess}
//         autoHideDuration={3000}
//         onClose={() => setUploadSuccess(false)}
//         anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
//       >
//         <Alert severity="success" variant="filled">
//           Attachments uploaded successfully!
//         </Alert>
//       </Snackbar>
//     </Box>
//   );
// };

// export default UploadAttachmentsToOneDrive;

import React, { useEffect, useState } from "react";
import {
  Box,
  Typography,
  Button,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  CircularProgress,
  Snackbar,
  Alert,
  ListItemButton,
  Checkbox,
  Divider,
  Drawer,
  IconButton,
  TextField,
} from "@mui/material";
import { FaCloudUploadAlt, FaCog, FaDatabase, FaFile, FaFileAlt, FaFileArchive, FaFileAudio, FaFileCode, FaFileCsv, FaFileExcel, FaFileImage, FaFilePdf, FaFilePowerpoint, FaFileVideo, FaFileWord } from "react-icons/fa";
import axios from "axios";
import LoaderApp from "../../Loader/Loader";
import { RiSettings5Line } from "react-icons/ri";

interface Attachment {
  id: string;
  name: string;
  contentType: string;
  contentBytes?: string;
}

const UploadAttachmentsToOneDrive = () => {
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [selectedAttachments, setSelectedAttachments] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);

  // Default paths state
  const [uploadPaths, setUploadPaths] = useState({
    path1: "Attachments",
    path2: "Path2",
    path3: "Path3",
  });

 
   useEffect(() => {
     const fetchAttachments = async () => {
       setLoading(true);
       const emailAttachments = Office.context.mailbox.item.attachments || [];
       const preparedAttachments = await prepareAttachments(emailAttachments);
       setAttachments(preparedAttachments);
       setLoading(false);
     };
 
     fetchAttachments();
   }, []);

  const prepareAttachments = async (attachments: Attachment[]) => {
    return Promise.all(
      attachments.map(async (attachment) => {
        try {
          return { ...attachment, contentBytes: "dummycontent" };
        } catch (error) {
          console.error("Error preparing attachment:", attachment.name, error);
          return { ...attachment, contentBytes: null };
        }
      })
    );
  };

  const toggleAttachmentSelection = (id: string) => {
    setSelectedAttachments((prev) =>
      prev.includes(id) ? prev.filter((attachmentId) => attachmentId !== id) : [...prev, id]
    );
  };


  const LoginAgain = (path) => {
    var a = "https://login.microsoftonline.com/common/oauth2/v2.0/authorize?client_id=e5a4342f-c8a5-4185-948d-2e3d485b4822&response_type=token&redirect_uri=https://localhost:3000/assets/Dialog.html&scope=mail.send+Files.ReadWrite.All+openid+profile+email&response_mode=fragment";
    Office.context.ui.displayDialogAsync(a, { height: 80, width: 60 }, function (asyncResult) {
    let  Logindialog = asyncResult.value;
      Logindialog.addEventHandler(Office.EventType.DialogMessageReceived, function (arg:any) {
      let  token = arg.message;
      uploadToPath(path,token,((data,error)=>{
        if(data){
          setUploadSuccess(true);
          setSelectedAttachments([]);
        }
        if(error&&error.status===401){
          setErrorMessage("Token is Expire Please Login.");
          LoginAgain(path)
        }
      }))
      // Save token and time in sessionStorage
      localStorage.setItem('Token', token);
        Logindialog.close();
      });
    });
  };


const handleSendEmail=(path: string)=>{
  const Token=localStorage.getItem('Token')
  uploadToPath(path,Token,((data,error)=>{
    if(data){
      setUploadSuccess(true);
      setSelectedAttachments([]);
    }
    if(error){

      if(error.status===401){
        setErrorMessage("Token is Expire Please Login.");
        LoginAgain(path)
      }else{
        setErrorMessage(error.message);

      }
    }
  }))
}

  const uploadToPath = async (path: string, Token: string, callback: (data:any,error:any) => void) => {
    if (selectedAttachments.length === 0) {
      setErrorMessage("No attachments selected for upload.");
      return;
    }

    setIsUploading(true);
    setErrorMessage("");

    try {
      for (const attachment of attachments.filter((a) => selectedAttachments.includes(a.id))) {
        if (!attachment.contentBytes) continue;

        const uploadUrl = `https://graph.microsoft.com/v1.0/me/drive/root:/${path}/${attachment.name}:/content`;
        await axios.put(uploadUrl, attachment.contentBytes, {
          headers: {
            Authorization: `Bearer ${Token}`,
            "Content-Type": attachment.contentType,
          },
        });
        console.log(`${attachment.name} uploaded successfully to ${path}`);
      }
callback('`${attachment.name} uploaded successfully to ${path}`',null)
      setUploadSuccess(true);
      setSelectedAttachments([]);
    } catch (error) {
      setErrorMessage("Error uploading to OneDrive. Please try again.");
      console.error("Upload error:", error);
callback(null,error)
    } finally {
      setIsUploading(false);
    }
  };

  const getIcon = (type: string) => {
    switch (type) {
      // Image Files
      case "image/png":
      case "image/jpeg":
      case "image/jpg":
      case "image/gif":
      case "image/webp":
      case "image/svg+xml":
      case "image/bmp":
        return <FaFileImage color="blue" fontSize={'xx-large'} />;
  
      // PDF Files
      case "application/pdf":
        return <FaFilePdf color="red" fontSize={'xx-large'}/>;
  
      // Word Documents
      case "application/msword":
      case "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
        return <FaFileWord color="blue" fontSize={'xx-large'} />;
  
      // Excel Files
      case "application/vnd.ms-excel":
      case "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
      case "text/csv":
        return <FaFileExcel color="green" fontSize={'xx-large'}/>;
  
      // CSV Files
      case "text/csv":
        return <FaFileCsv color="teal"  fontSize={'xx-large'}/>;
  
      // PowerPoint Files
      case "application/vnd.ms-powerpoint":
      case "application/vnd.openxmlformats-officedocument.presentationml.presentation":
        return <FaFilePowerpoint color="orange" fontSize={'xx-large'} />;
  
      // Archive Files
      case "application/zip":
      case "application/x-7z-compressed":
      case "application/x-rar-compressed":
      case "application/x-tar":
      case "application/gzip":
        return <FaFileArchive color="brown" fontSize={'xx-large'}/>;
  
      // Text Files
      case "text/plain":
        return <FaFileAlt color="gray" fontSize={'xx-large'}/>;
  
      // Audio Files
      case "audio/mpeg":
      case "audio/wav":
      case "audio/ogg":
      case "audio/aac":
      case "audio/x-midi":
        return <FaFileAudio color="purple" fontSize={'xx-large'}/>;
  
      // Video Files
      case "video/mp4":
      case "video/x-msvideo":
      case "video/mpeg":
      case "video/ogg":
      case "video/webm":
      case "video/x-matroska":
        return <FaFileVideo color="red"fontSize={'xx-large'} />;
  
      // Code Files
      case "text/html":
      case "application/javascript":
      case "application/json":
      case "text/css":
      case "application/xml":
        return <FaFileCode color="green"fontSize={'xx-large'} />;
  
      // Database Files
      case "application/vnd.ms-access":
      case "application/x-sqlite3":
      case "application/x-msdownload":
        return <FaDatabase color="brown"fontSize={'xx-large'} />;
  
      // Default (Unknown or Unhandled Types)
      default:
        return <FaFile color="black" fontSize={'xx-large'}/>;
    }
  };

  const handleCancel = () => {
    setDrawerOpen(false);
  };

  const handleSave = () => {
    setDrawerOpen(false);
  };



  return (
    <Box sx={{ maxWidth: 600, margin: "auto", backgroundColor: "#fff" }}>
     {loading && <LoaderApp />}
           
      <Typography variant="h5" sx={{ marginBottom: 2, textAlign: "center", fontWeight: "bold", display:'flex', alignItems:'center', justifyContent:'space-between', fontSize:'20px' }}>
        <div>
        <FaCloudUploadAlt style={{ marginRight: 8, verticalAlign: "middle" }} />
        Upload To OneDrive
        </div>
              <IconButton
                sx={{ float: "right", marginBottom:'5px'}}
                color="primary"
                onClick={() => setDrawerOpen(true)}
              >
                <RiSettings5Line />
              </IconButton>
            </Typography>
            
            <Box sx={{ maxHeight: 300, overflow: "auto" }}>
        <List>
           {attachments.length === 0 && !loading && (
                <Box textAlign="center" p={2}>
                  No Attachment Found with the selected mail
                </Box>
              )}
          {attachments.map((attachment) => (
            <React.Fragment key={attachment.id}>
              <ListItem disablePadding>
                <Checkbox
                  checked={selectedAttachments.includes(attachment.id)}
                  onChange={() => toggleAttachmentSelection(attachment.id)}
                />
                <ListItemButton>
                  <ListItemIcon>
                  {getIcon(attachment.contentType)}
                  </ListItemIcon>
                  <ListItemText primary={attachment.name} />
                </ListItemButton>
              </ListItem>
              <Divider />
            </React.Fragment>
          ))}
        </List>
      </Box>

      {/* Upload Buttons */}
      <Box >
        <Typography variant="h6" sx={{ fontSize: "15px", marginTop:'10px'  }}>Upload to {uploadPaths.path1}</Typography>
        <Button
          variant="contained"
          color="primary"
          fullWidth
          sx={{
            "&.Mui-disabled": {
                          backgroundColor: "#93C0FE",
                          color: "white"
                      },
          }}
          disabled={isUploading || !selectedAttachments.length}
          onClick={() => handleSendEmail(uploadPaths.path1)}
        >
         Upload
        </Button>
      </Box>

      <Box >
        <Typography variant="h6" sx={{ fontSize: "15px" ,marginTop:'10px'  }}>Upload to {uploadPaths.path2}</Typography>
        <Button
          variant="contained"
          color="primary"
          fullWidth
          sx={{
            "&.Mui-disabled": {
                          backgroundColor: "#93C0FE",
                          color: "white"
                      },
          }}
          disabled={isUploading || !selectedAttachments.length}
          onClick={() => handleSendEmail(uploadPaths.path2)}
        >
         Upload
        </Button>
      </Box>

      <Box >
        <Typography variant="h6" sx={{ fontSize: "15px" ,marginTop:'10px'  }}>Upload to {uploadPaths.path3}</Typography>
        <Button
          variant="contained"
          color="primary"
          fullWidth
          sx={{
            "&.Mui-disabled": {
                          backgroundColor: "#93C0FE",
                          color: "white"
                      },
          }}
          disabled={isUploading || !selectedAttachments.length}
          onClick={() => handleSendEmail(uploadPaths.path3)}
        >
         Upload
        </Button>
      </Box>

      {/* Success and Error Messages */}
      {errorMessage && (
        <Alert severity="error" sx={{ marginTop: 2 }} onClose={() => setErrorMessage("")}>
          {errorMessage}
        </Alert>
      )}

      <Snackbar
        open={uploadSuccess}
        autoHideDuration={3000}
        onClose={() => setUploadSuccess(false)}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <Alert severity="success" variant="filled">
          Attachments uploaded successfully!
        </Alert>
      </Snackbar>

      {/* Settings Drawer */}
      <Drawer anchor="right" open={drawerOpen} onClose={() => setDrawerOpen(false)}>
        <Box sx={{ width: 300, padding: 2 }}>
          <Typography variant="h6">Edit Upload Paths</Typography>

          <TextField
            label="Path 1"
            fullWidth
            margin="normal"
            value={uploadPaths.path1}
            onChange={(e) => setUploadPaths({ ...uploadPaths, path1: e.target.value })}
          />

          <TextField
            label="Path 2"
            fullWidth
            margin="normal"
            value={uploadPaths.path2}
            onChange={(e) => setUploadPaths({ ...uploadPaths, path2: e.target.value })}
          />

          <TextField
            label="Path 3"
            fullWidth
            margin="normal"
            value={uploadPaths.path3}
            onChange={(e) => setUploadPaths({ ...uploadPaths, path3: e.target.value })}
          />

         <div style={{width:'100%', display:'flex', justifyContent:'space-between', alignItems:'center'}}>
                   
                   <Button variant="outlined"  sx={{width:'49%'}} onClick={handleCancel}>
                     Cancel
                   </Button>
                   <Button variant="contained" color='primary' sx={{width:'49%'}}  onClick={()=>setDrawerOpen(false)}>
                     Save
                   </Button>
                   </div>
                   
        </Box>
      </Drawer>
    </Box>
  );
};

export default UploadAttachmentsToOneDrive;
