import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  TextField,
  Button,
  IconButton,
  Drawer,
  Card,
  CardHeader,
  CardContent,
  Avatar,
  CardActions,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from "@mui/material";
import { red } from "@mui/material/colors";
import { RiMailSendLine, RiSettings5Line } from "react-icons/ri";
import { FaArrowsLeftRight, FaRegCopy } from "react-icons/fa6";
import pdfMake from "pdfmake/build/pdfmake";
import pdfFonts from "pdfmake/build/vfs_fonts";
import { OpenDialog } from "../../utils/OpenDialog";

// Ensure vfs is set properly
if (pdfFonts && pdfFonts.pdfMake && pdfFonts.pdfMake.vfs) {
  pdfMake.vfs = pdfFonts.pdfMake.vfs;
} else {
  console.error("pdfFonts.vfs is not available.");
}

const PDFGenerator = () => {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedText, setSelectedText] = useState("");
  const [textToCopy, setTextToCopy] = useState("");
  const [emailSettings, setEmailSettings] = useState({
    email1: "example1@gmail.com",
    email2: "example2@gmail.com",
    email3: "example3@gmail.com",
  });
  const [editedEmails, setEditedEmails] = useState(emailSettings);
  const [emailDetails, setEmailDetails] = useState({
    body: "",
    senderEmail: "",
    sentDate: "",
    senderInitials: "",
  });
  const [showFullText, setShowFullText] = useState(false);  // State to toggle show more/less

  useEffect(() => {
    // Fetch email details using Office.js
    Office.context.mailbox.item.body.getAsync("text", (result) => {
      if (result.status === Office.AsyncResultStatus.Succeeded) {
        setEmailDetails((prev) => ({
          ...prev,
          body: result.value,
        }));
      }
    });

    const sender = Office.context.mailbox.item.from;
    setEmailDetails((prev) => ({
      ...prev,
      senderEmail: sender.emailAddress,
      sentDate: Office.context.mailbox.item.dateTimeCreated.toLocaleDateString(),
      senderInitials: sender.displayName
        .split(" ")
        .map((word) => word[0])
        .join("")
        .slice(0, 2),
    }));
  }, []);

  const handleCopy = (text) => {
    navigator.clipboard.writeText(text).then(() => {
      setTextToCopy(text);
      setDialogOpen(true);
    });
  };

  const handleTextSelect = () => {
    const selected = window.getSelection()?.toString() || "";
    if (selected) {
      setSelectedText(selected);
      handleCopy(selected);
    }
  };

  const generatePDF = (text) => {
    const docDefinition = {
      content: [
        {
          text:Office.context.mailbox.item.subject,
          style: "header",
        },
        {
          text,
          style: "body",
        },
      ],
      styles: {
        header: {
          fontSize: 18,
          bold: true,
          marginBottom: 10,
        },
        body: {
          fontSize: 12,
          lineHeight: 1.5,
        },
      },
    };

    pdfMake.createPdf(docDefinition).download("SelectedText.pdf");
  };


  const OpenFullWindow=()=>{
        OpenDialog()
  }
  return (
    <div>
      <Box>
        <Typography
          variant="h5"
          sx={{
            marginBottom: 2,
            textAlign: "center",
            fontWeight: "bold",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            fontSize: "20px",
          }}
        >
          <div>
            <RiMailSendLine style={{ marginRight: 8, verticalAlign: "middle" }} />
            Send OR Upload Pdf
          </div>
          <IconButton
            sx={{ float: "right", marginBottom: "5px" }}
            color="primary"
            onClick={() => setDrawerOpen(true)}
          >
            <RiSettings5Line />
          </IconButton>
        </Typography>

        <Card
          sx={{
            maxWidth: "100%",
            boxShadow: "0px 1px 10px 2px #f1f1f1",
            marginBottom: "10px",
            maxHeight:'500px',
            overflow:'auto',
            scrollbarWidth:'none',
            scrollBehavior:'smooth'
          }}
          onMouseUp={handleTextSelect}
        >
          <CardHeader
            avatar={
              <Avatar sx={{ bgcolor: red[500] }} aria-label="sender">
                {emailDetails.senderInitials}
              </Avatar>
            }
            action={
              <IconButton aria-label="settings" sx={{ fontSize: "20px", marginTop: "5px" }} onClick={OpenFullWindow}>
                <FaArrowsLeftRight style={{ rotate: "130deg" }} />
              </IconButton>
            }
            title={emailDetails.senderEmail}
            subheader={emailDetails.sentDate}
          />
          <CardContent>
            <Typography variant="body2" sx={{ color: "text.secondary" }}>
              {showFullText
                ? emailDetails.body
                : emailDetails.body.substring(0, 200) + "..."}
              <Button
                size="small"
                color="primary"
                onClick={() => setShowFullText((prev) => !prev)}  // Toggle show more/less
              >
                {showFullText ? "Show Less" : "Show More"}
              </Button>
            </Typography>
          </CardContent>
          <CardActions disableSpacing>
            <IconButton aria-label="copy to clipboard" onClick={() => handleCopy(emailDetails.body)}>
              <FaRegCopy style={{ fontSize: "19px" }} />
            </IconButton>
          </CardActions>
        </Card>
      </Box>

      {/* Drawer for settings */}
      <Drawer anchor="right" open={drawerOpen} onClose={() => setDrawerOpen(false)}>
        <Box sx={{ width: 300, padding: 2}}>
          <Typography variant="h6" sx={{ marginBottom: 2 }}>
            Edit Email Addresses
          </Typography>
          {Object.entries(editedEmails).map(([key, email]) => (
            <TextField
              key={key}
              fullWidth
              label={`Email ${key.split("email")[1]}`}
              value={email}
              onChange={(e) =>
                setEditedEmails((prev) => ({ ...prev, [key]: e.target.value }))
              }
              sx={{ marginBottom: 2 }}
            />
          ))}
          <div
            style={{
              width: "100%",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <Button variant="outlined" sx={{ width: "49%" }} onClick={() => setDrawerOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="contained"
              color="primary"
              sx={{ width: "49%" }}
              onClick={() => setDrawerOpen(false)}
            >
              Save
            </Button>
          </div>
        </Box>
      </Drawer>

      {/* Modal Dialog */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)}>
        <DialogTitle>Generate PDF</DialogTitle>
        <DialogContent>
          <Typography>
            The text has been copied. Do you want to generate a PDF of the copied text?
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>No</Button>
          <Button
            onClick={() => {
              generatePDF(textToCopy);
              setDialogOpen(false);
            }}
          >
            Yes
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default PDFGenerator;
