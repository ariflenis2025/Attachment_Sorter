import React from 'react'
import RouterApp from './router/Routes'

const App = () => {
  return (
    <RouterApp/>
  )
}

export default App