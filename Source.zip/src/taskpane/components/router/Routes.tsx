/* eslint-disable react/jsx-no-undef */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable no-undef */
/* eslint-disable prettier/prettier */
import React, { useEffect, useState } from "react";
import { HashRouter as Router, Routes, Route } from "react-router-dom";
// import Login from "../layout/Main/UploadAttachmentsToOneDrive";
import Home from "../layout/Main/Home";
import Getstart from "../layout/Main/GetStart";


const RouterApp: React.FC = () => {
    
  
    return (
        <>
            <Router>
                <Routes>
                    <Route path="/" element={<Getstart />} />
                    <Route path="/Home" element={<Home />} />
                </Routes>
            </Router>
        </>
    )

}

export default RouterApp;